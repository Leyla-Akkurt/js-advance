# JSON methods - Exercise 3

In this exercises something goes wrong. Even though we have created a copy of `person1`, modifying the property `city` of `person2` changes even the value for `person1`. This happens because we have created a shallow copy.
How we can fix the code, in order to modify the values of `person2` without changing the one of `person1`?
