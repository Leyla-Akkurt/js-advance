# JSON methods - Exercise 1

Convert the `developer` object into json.
