# JSON methods

In this exercise we need to filter the properties of the object `person` in order to convert into JSON just the values of `id` and `age`.
