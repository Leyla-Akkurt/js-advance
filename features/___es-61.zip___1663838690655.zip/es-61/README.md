# Destructuring assignment - 61

Use the destructuring to assign the values just with one code line.
