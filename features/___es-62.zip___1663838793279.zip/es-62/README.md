# Destructuring assignment - Exercise 62

Use the destructuring to make the check of the age easier. Try to modify the parameter that the function `isAdult` takes in.
Suggestion: look at the official documentation[ https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Destructuring_assignment](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Destructuring_assignment)
