# Rest parameters and spread syntax - Exercise 65

The `sum` function has a high numbers of parameters. How can we improve the code in order to make it accept an unknown numbers to sum?
