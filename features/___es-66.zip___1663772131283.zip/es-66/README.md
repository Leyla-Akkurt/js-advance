# Rest parameters and spread syntax

Perform a code refactoring by using the Rest operator. The output of the console.log must not change.
