# Destructuring assignment - 63

The destructuring returns `undefined` for the properties: `name`, `surname` and `old`. Try to fix the code without changing the name properties of the object `person`.
